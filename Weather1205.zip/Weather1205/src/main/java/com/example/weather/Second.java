package com.example.weather;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Second {
private Stage stage;
private Scene scene;
private Parent parent;

@FXML
Label tempMon;
@FXML
Label tempTue;
@FXML
Label tempWed;
@FXML
Label tempThur;
@FXML
Label tempFri;
@FXML
Label tempSat;
@FXML
Label tempSun;
@FXML
Label precMon;
@FXML
Label precTue;
@FXML
Label precWed;
@FXML
Label precThur;
@FXML
Label precFri;
@FXML
Label precSat;
@FXML
Label precSun;

String string;





    public void switchtoscene2withoutbutton(ActionEvent event) throws IOException {
    FXMLLoader root= new FXMLLoader(getClass().getResource("second.fxml"));
    stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        parent = root.load();
    scene=new Scene(parent);
    String be=getClass().getResource("Background.css").toExternalForm();
        Third third=root.getController();
        third.getlistofthings(string);
    scene.getStylesheets().add(be);
    stage.setScene(scene);
    stage.show();
}



    public void getlistofthings(String store) {
    	this.string=store;
    	store = store;
    	
    	   // Coordinates for Detroit (replace as needed)
     //   double latitude = 42.3314;
      //  double longitude = -83.0458;
        double latitude = 0, longitude = 0;
    	String coordinateCall = coordCall(store);
    	 if (!coordinateCall.startsWith("Error")) {
             try {
            	 JSONObject jsonResponse = new JSONObject(coordinateCall);
            	 
            	 JSONArray coords = jsonResponse.getJSONArray("results");
            	 if(coords.length() > 0 ) {
            	 
            	 JSONObject coordsObj = coords.getJSONObject(0);
            	 
            	 latitude = coordsObj.getDouble("latitude");
            	 longitude = coordsObj.getDouble("longitude");
            	 System.out.println(latitude + " " + longitude);
            	 }
            	 else
            		 System.out.println("No results found");
             }catch(JSONException e) {
             	System.out.println("Invalid Location");
             	e.printStackTrace();
              }
             catch (Exception e) {
                 e.printStackTrace();
                 tempMon.setText("Error");
                 tempTue.setText("Error");
                 tempWed.setText("Error");
                 tempThur.setText("Error");
                 tempFri.setText("Error");
                 tempSat.setText("Error");
                 tempSun.setText("Error");
                 precMon.setText("Error");
                 precTue.setText("Error");
                 precWed.setText("Error");
                 precThur.setText("Error");
                 precFri.setText("Error");
                 precSat.setText("Error");
                 precSun.setText("Error");
             }
             
        String WeeklyWeatherData = fetchWeeklyWeatherData(latitude, longitude);
        if (!WeeklyWeatherData.startsWith("Error")) {
            try {
        JSONObject jsonResponse = new JSONObject(WeeklyWeatherData);
        JSONObject daily = jsonResponse.getJSONObject("daily");
        var temperatures = daily.getJSONArray("temperature_2m_max");
        Label[] weeklyTemps = {tempMon, tempTue, tempWed, tempThur, tempFri, tempSat, tempSun};
        
        for(int i = 0; i < weeklyTemps.length; i++) {
        	 String temperature = temperatures.getDouble(i) + "°C";
        	weeklyTemps[i].setText(temperature);
        }
        
        var precip = daily.getJSONArray("precipitation_probability_max");
        Label[] weeklyPrecip = { precMon,precTue,precWed,precThur,precFri,precSat,precSun};
        
        for(int j = 0; j < weeklyPrecip.length; j++) {
        	String precipChance = precip.getDouble(j) + "%";
        	weeklyPrecip[j].setText(precipChance);
        }
        
            }catch (Exception e) {
                e.printStackTrace();
                tempMon.setText("Error");
                tempTue.setText("Error");
                tempWed.setText("Error");
                tempThur.setText("Error");
                tempFri.setText("Error");
                tempSat.setText("Error");
                tempSun.setText("Error");
                precMon.setText("Error");
                precTue.setText("Error");
                precWed.setText("Error");
                precThur.setText("Error");
                precFri.setText("Error");
                precSat.setText("Error");
                precSun.setText("Error");
            }
        }
        }
    }
    
 public String coordCall(String location) {
    	
    	String apiURL = "https://geocoding-api.open-meteo.com/v1/search?name="+location+"&count=10&language=en&format=json";
    	  try {
              HttpClient client = HttpClient.newHttpClient();

              HttpRequest request = HttpRequest.newBuilder()
                      .uri(URI.create(apiURL))
                      .GET()
                      .build();

              HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

              if (response.statusCode() == 200) {
                  return response.body(); // Return the raw JSON response
              } else {
                  return "Error: Unable to fetch coordinates (HTTP " + response.statusCode() + ").";
              }
          } catch (Exception e) {
              e.printStackTrace();
              return "Error: Exception occurred while fetching coordinates.";
          }
      }
    

    //weather data fetch for weekly forecast
    public static String fetchWeeklyWeatherData(double latitude, double longitude) {
    	String apiUrl = "https://api.open-meteo.com/v1/forecast?latitude="+latitude+"&longitude="+longitude+"&daily=temperature_2m_max,precipitation_probability_max";
    	
    	  try {
              HttpClient client = HttpClient.newHttpClient();

              HttpRequest request = HttpRequest.newBuilder()
                      .uri(URI.create(apiUrl))
                      .GET()
                      .build();

              HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

              if (response.statusCode() == 200) {
                  return response.body(); // Return the raw JSON response
              } else {
                  return "Error: Unable to fetch weather data (HTTP " + response.statusCode() + ").";
              }
          } catch (Exception e) {
              e.printStackTrace();
              return "Error: Exception occurred while fetching weather data.";
          }
      }
}

