package com.example.weather;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class Second {
private Stage stage;
private Scene scene;
private Parent parent;

@FXML
Label tempmon;
@FXML
Label temptues;
@FXML
Label tempwends;
@FXML
Label tempthrus;
@FXML
Label tempfri;
@FXML
Label tempsat;
@FXML
Label tempsun;
@FXML
Label precmon;
@FXML
Label prectues;
@FXML
Label precwends;
@FXML
Label precthurs;
@FXML
Label precfri;
@FXML
Label precsat;
@FXML
Label precsun;

String string;





    public void switchtoscene2withoutbutton(ActionEvent event) throws IOException {
    FXMLLoader root= new FXMLLoader(getClass().getResource("second.fxml"));
    stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        parent = root.load();
    scene=new Scene(parent);
    String be=getClass().getResource("Background.css").toExternalForm();
        Third third=root.getController();
        third.getlistofthings(string);    //this is to send the weather data from second to third.
    scene.getStylesheets().add(be);
    stage.setScene(scene);
    stage.show();
}



    public void getlistofthings(String store) {
this.string=store;
    }
}


