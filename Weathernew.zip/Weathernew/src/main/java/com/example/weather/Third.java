package com.example.weather;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Third {

    private Stage stage;
    private Scene scene;
    private Parent parent;
@FXML
    Label currently;
@FXML
Label type;
@FXML
Label speed;
@FXML
Label temp;
@FXML
Label label1am;
@FXML
Label label2am;
@FXML
Label label3am;
@FXML
Label label4am;
@FXML
Label label5am;
@FXML
Label label6am;
@FXML
Label label7am;
@FXML
Label label8am;
@FXML
Label label9am;
@FXML
Label label10am;
@FXML
Label label11am;
@FXML
Label label12am;
@FXML
Label label3pm;
@FXML
Label label4pm;
@FXML
Label label5pm;
@FXML
Label label6pm;
@FXML
Label label7pm;
@FXML
Label label8pm;
@FXML
Label label9pm;
@FXML
Label label2pm;
@FXML
Label label1pm;
@FXML
Label label10pm;
@FXML
Label label12pm;
@FXML
Label label11pm;
@FXML
Label chance;
@FXML
Label Precaction;
@FXML
Label Time;
@FXML
Label loc;

String store;
@FXML
public void getlistofthings(String location) {
    store = location;
    fetchWeatherData(location);  // Fetch weather data for the location

    // Set static text labels
    currently.setText("Currently");
    type.setText("Weather in " + location + " is:");
    chance.setText("Chance of Rain:");  // Update with actual data if available
    Time.setText("Time: " + java.time.LocalDate.now().toString());  // Display current date
    loc.setText(location);
}

    public void switchtosecence3(ActionEvent event) throws IOException {
        FXMLLoader root= new FXMLLoader(getClass().getResource("third.fxml"));
        parent=root.load();
        stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(parent);
        Second second=root.getController();
          second.getlistofthings(store); //this is to send the weather data from third to second.
       String be=getClass().getResource("Background2.css").toExternalForm();
       scene.getStylesheets().add(be);
        stage.setScene(scene);
        stage.show();

    }

    public void switchtosecence1(ActionEvent event) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        String be=getClass().getResource("Background2.css").toExternalForm();
        scene.getStylesheets().add(be);
        stage.setScene(scene);
        stage.show();

    }


    public void getlistofthings(MouseEvent mouseEvent) {

   }
    
    private void fetchWeatherData(String location) {
        String apiUrl = "https://api.open-meteo.com/v1/forecast?latitude=YOUR_LATITUDE&longitude=YOUR_LONGITUDE&current_weather=true";
        
        try {
            // Make API call
            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            // Read the response
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                response.append(line);
            }
            in.close();

            // Parse JSON response
            JSONObject jsonResponse = new JSONObject(response.toString());
            JSONObject currentWeather = jsonResponse.getJSONObject("current_weather");

            // Extract data
            String temperature = currentWeather.getString("temperature");
            String windSpeed = currentWeather.getString("windspeed");
            String weatherCode = currentWeather.getString("weathercode");

            // Update labels with fetched data
            temp.setText("Temperature: " + temperature + "°C");
            speed.setText("Wind Speed: " + windSpeed + " km/h");
            type.setText("Weather Code: " + weatherCode);
        } catch (Exception e) {
            e.printStackTrace();
            temp.setText("Error fetching data.");
        }
    }
}
