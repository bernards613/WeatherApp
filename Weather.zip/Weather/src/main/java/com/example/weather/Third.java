package com.example.weather;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class Third {
private Stage stage;
private Scene scene;
private Parent parent;

@FXML
Label temp1;
@FXML
Label temp2;
@FXML
Label temp3;
@FXML
Label temp4;
@FXML
Label temp5;
@FXML
Label temp6;
@FXML
Label temp7;
@FXML
Label prec1;
@FXML
Label prec2;
@FXML
Label prec3;
@FXML
Label prec4;
@FXML
Label prec5;
@FXML
Label prec6;
@FXML
Label prec7;

String string;

//add data from metro api for weekly temp. and prec.
public void adddata(){
String weatherdata=getlistofthings();
//api stuff
 temp1.setText("");
 temp2.setText("");
 temp3.setText("");
 temp4.setText("");
 temp5.setText("");
 temp6.setText("");
 temp7.setText("");
   prec1.setText("");
   prec2.setText("");
     prec3.setText("");
     prec4.setText("");
    prec5.setText("");
     prec6.setText("");
    prec7.setText("");



}

     // for third.html goes back to
    public void switchtoscene2withouttextbox(ActionEvent event) throws IOException {
    FXMLLoader root= new FXMLLoader(getClass().getResource("second.fxml"));
    stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        parent = root.load();
    scene=new Scene(parent);
    String be=getClass().getResource("Background.css").toExternalForm();
        Second second=root.getController();
        second.getlistofthings(string);
    scene.getStylesheets().add(be);
    stage.setScene(scene);
    stage.show();
}


//both collect data from second slide
public String getlistofthings(){

    return this.string;
}

    public void setlistofthings(String store) {
this.string=store;
    }
}


