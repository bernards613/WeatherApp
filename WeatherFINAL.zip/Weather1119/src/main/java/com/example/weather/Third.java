package com.example.weather;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.IOException;
import org.json.JSONObject;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class Third {

    private Stage stage;
    private Scene scene;
    private Parent parent;
    @FXML
    Label currently;
@FXML
Label type;
@FXML
Label speed;
@FXML
Label temp;
@FXML
Label label1am;
@FXML
Label label2am;
@FXML
Label label3am;
@FXML
Label label4am;
@FXML
Label label5am;
@FXML
Label label6am;
@FXML
Label label7am;
@FXML
Label label8am;
@FXML
Label label9am;
@FXML
Label label10am;
@FXML
Label label11am;
@FXML
Label label12am;
@FXML
Label label3pm;
@FXML
Label label4pm;
@FXML
Label label5pm;
@FXML
Label label6pm;
@FXML
Label label7pm;
@FXML
Label label8pm;
@FXML
Label label9pm;
@FXML
Label label2pm;
@FXML
Label label1pm;
@FXML
Label label10pm;
@FXML
Label label12pm;
@FXML
Label label11pm;
@FXML
Label chance;
@FXML
Label Precipitation;
@FXML
Label Date;
@FXML
Label loc;
@FXML
Label condition;

String store;
@FXML

public void getlistofthings(String location) {
    store = location;

    // Coordinates for Detroit (replace as needed)
    double latitude = 42.3314;
    double longitude = -83.0458;

    // Fetch the weather data
    String weatherData = fetchWeatherData(latitude, longitude);

    // Parse JSON and update the GUI
    if (!weatherData.startsWith("Error")) {
        try {
            // Parse the JSON response
            JSONObject jsonResponse = new JSONObject(weatherData);

            // Extract current weather data
            JSONObject currentWeather = jsonResponse.getJSONObject("current_weather");
            double currentTemp = currentWeather.getDouble("temperature");
            double windSpeed = currentWeather.getDouble("windspeed");
            int weatherCode = currentWeather.getInt("weathercode");

            temp.setText("Temperature: " + currentTemp + "°C");
            speed.setText("Wind Speed: " + windSpeed + " km/h");
            
            //Check for storm warnings and update condition label
            String warningMessage = getStormWarning(weatherCode);
            condition.setText(warningMessage);

            // Extract hourly temperature data
            JSONObject hourly = jsonResponse.getJSONObject("hourly");
            var temperatures = hourly.getJSONArray("temperature_2m");
            var precipitationProbabilities = hourly.getJSONArray("precipitation_probability");
            
         // Calculate the max precipitation probability for the day
            int maxPrecipitation = 0;
            for (int i = 0; i < precipitationProbabilities.length(); i++) {
                maxPrecipitation = Math.max(maxPrecipitation, precipitationProbabilities.getInt(i));
            }

            // Update precipitation label
            chance.setText("Rain Chance: " + maxPrecipitation + "%");

            // Array of hourly labels
            Label[] hourlyLabels = {
                label1am, label2am, label3am, label4am, label5am, label6am, label7am,
                label8am, label9am, label10am, label11am, label12am,
                label1pm, label2pm, label3pm, label4pm, label5pm, label6pm,
                label7pm, label8pm, label9pm, label10pm, label11pm, label12pm
            };

            // Fill in labels with temperatures
            for (int i = 0; i < hourlyLabels.length; i++) {
                String temperature = temperatures.getDouble(i) + "°C";
                hourlyLabels[i].setText(temperature);
            }
        } catch (Exception e) {
            e.printStackTrace();
            temp.setText("Error fetching temperature.");
            speed.setText("Error fetching wind speed.");
            chance.setText("Error fetching precipitation chance.");
        }
    } else {
        temp.setText("Unable to fetch temperature.");
        speed.setText("Unable to fetch wind speed.");
        chance.setText("Unable to fetch precipitation chance.");
    }

    // Set static labels
    currently.setText("Currently");
    type.setText("Weather in " + location + " is:");
    Date.setText("Date: " + java.time.LocalDate.now().toString());  // Display current date
    loc.setText(location);
}
														
    public void switchtosecence3(ActionEvent event) throws IOException {
        FXMLLoader root= new FXMLLoader(getClass().getResource("third.fxml"));
        parent=root.load();
        stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(parent);
        Second second=root.getController();
          second.getlistofthings(store);
       String be=getClass().getResource("Background2.css").toExternalForm();
       scene.getStylesheets().add(be);
        stage.setScene(scene);
        stage.show();

    }

    public void switchtosecence1(ActionEvent event) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        String be=getClass().getResource("Background2.css").toExternalForm();
        scene.getStylesheets().add(be);
        stage.setScene(scene);
        stage.show();

    }


    public void getlistofthings(MouseEvent mouseEvent) {

    }
    
    public static String fetchWeatherData(double latitude, double longitude) {
        String apiUrl = "https://api.open-meteo.com/v1/forecast?latitude=" + latitude
                + "&longitude=" + longitude + "&current_weather=true&hourly=temperature_2m,precipitation_probability,precipitation_type";

        try {
            HttpClient client = HttpClient.newHttpClient();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(apiUrl))
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                return response.body(); // Return the raw JSON response
            } else {
                return "Error: Unable to fetch weather data (HTTP " + response.statusCode() + ").";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "Error: Exception occurred while fetching weather data.";
        }
    }
    
    //Helper method for storm warnings
    public static String getStormWarning(int weatherCode) {
        // Interpret the weather code
        switch (weatherCode) {
            case 95: // Thunderstorms
            case 96: // Thunderstorms with slight hail
            case 99: // Thunderstorms with heavy hail
                return "Storm Warning: Severe thunderstorms expected.";
            case 80: // Rain showers
            case 81: // Heavy rain showers
            case 82: // Violent rain showers
                return "Storm Warning: Heavy rain showers possible.";
            default:
                return "No storm warning.";
        }
    }
}
